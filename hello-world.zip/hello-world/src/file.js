let q = [1, 2, 5, 3, 7, 8, 6, 4]
let swaps = 0;
let totalSwaps = 0;
do {
    console.log('looping')
    let swaps = 0;
    for (let i = 0; i < q.length; i++) {
        if (i == q.length - 1)
            continue;
        if (q[i] > q[i + 1]) {
            let elementToSwap = q[i + 1];
            q[i + 1] = q[i];
            q[i] = elementToSwap;
            swaps++;
            totalSwaps++;
        }
    }
    console.log(swaps)
}
while (swaps > 0);
console.log(totalSwaps);
console.log(q);

let subStrings = [];
for (let i = 0; i < s.length; i++) {
    for (let j = 0; j < s.length; j++) {
        if (i > j)
            continue;
        subStrings.push(s.substring(i, j + 1).split('').sort().join(''));
    }
}
console.log(subStrings);

let pairs = 0;

for (let k = 0; k < subStrings.length; k++) {
    pairs += subStrings.filter((pair, index) => index > k && pair === subStrings[k]).length - 1;
}
return pairs;
